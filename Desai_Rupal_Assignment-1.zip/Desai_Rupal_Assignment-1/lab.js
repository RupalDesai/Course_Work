const questionOne = function questionOne(arr) {
    // Implement question 1 here
var sum = 0;
for (j=0;j<arr.length;j++)
sum =sum+ Math.pow(arr[j], 2);
return sum;
}

const questionTwo = function questionTwo(num) { 
    // Implement question 2 here
   
    if(num<=0){
      return 0;
    }
    else if(num===1){
      return 1;
    }
    else{
      return questionTwo(num-1)+questionTwo(num-2);
    }
}

const questionThree = function questionThree(text) {
    // Implement question 3 here
    var vCount = 0;
    
      var str = text.toString();
      for (var i = 0; i <= str.length - 1; i++) {
  
        if (str.charAt(i) == "a" || str.charAt(i) == "e" || str.charAt(i) == "i" || str.charAt(i) == "o" || str.charAt(i) == "u") {
          vCount += 1;
        }
      }
      return vCount;
}

const questionFour = function questionFour(num) {
    // Implement question 4 here
    if (num < 0) 
    return -1;
else if (num == 0) 
  return 1;
else {
  return (num * questionFour(num - 1));
}
    
}

module.exports = {
    firstName: "Rupal", 
    lastName:  "Desai", 
    studentId: "10431020",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};