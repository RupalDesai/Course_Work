function checkIsProperNumber(val, variableName) {
    if (typeof val !== "number") {
      throw `${variableName || "provided variable"} is not a number`;
    }
  
    if (isNaN(val)) {
      throw `${variableName || "provided variable"} is NaN`;
    }
    
    if (val<0) {
        throw `${variableName || "provided variable"} is less than zero`;
      }
      if (val===0) {
        throw `${variableName || "provided variable"} is zero`;
      }
  }
  
module. exports = {
volumeOfRectangularPrism: function(length, width, height) {

    
    checkIsProperNumber(length,"length");
    checkIsProperNumber(width, "width");    
    checkIsProperNumber(height, "height");

    return length*width*height;
},

surfaceAreaOfRectangularPrism: function (length, width, height){
    
    checkIsProperNumber(length,"length");
    checkIsProperNumber(width, "width");    
    checkIsProperNumber(height, "height");
return 2*(width*length+height*length+height*width);
},

volumeOfSphere : function (radius){
    
     checkIsProperNumber(radius,"radius");

return (4/3)* Math.PI * Math.pow(radius, 3);
},

surfaceAreaOfSphere : function (radius){
    
    checkIsProperNumber(radius,"radius");
return 4 * Math.PI * Math.pow(radius,2);
}
};