const geometry = require("./geometry");
const utilities = require("./utilities");

console.log("Geometry section");


console.log("");
console.log("Volume of Rectangular Prism is");
try{
let VolOfRectPrism1=geometry.volumeOfRectangularPrism(-1,4,7);
console.log("Answer "+VolOfRectPrism1);
}
catch(err){
    console.log(err);
}
try{
    let VolOfRectPrism2=geometry.volumeOfRectangularPrism(3,1,0);
console.log("Answer  "+VolOfRectPrism2);
}
catch(err){
    console.log(err);
}
try{
    let VolOfRectPrism3=geometry.volumeOfRectangularPrism(1,2,null);
console.log("Answer  "+VolOfRectPrism3);
}
catch(err){
    console.log(err);
}
try{
   let VolOfRectPrism4=geometry.volumeOfRectangularPrism(4,7,4);
console.log("Answer  "+VolOfRectPrism4); 
}
catch(err){
    console.log(err);
}
try{
   let VolOfRectPrism5=geometry.volumeOfRectangularPrism(1.7,4,5);
console.log("Answer"+VolOfRectPrism5); 
}
catch(err){
    console.log(err);
}


console.log("");
console.log("Surface area of Rectangular Prism is");
try{
    let SurfAreaOfRectPrism1=geometry.surfaceAreaOfRectangularPrism(4.4,6,8);
console.log(" Answer"+SurfAreaOfRectPrism1);
}
catch(err){
    console.log(err);
}

try{
    let SurfAreaOfRectPrism2=geometry.surfaceAreaOfRectangularPrism(3.3,-1,0);
console.log(" Answer"+SurfAreaOfRectPrism2);
}
catch(err){
    console.log(err);
}

try{
    let SurfAreaOfRectPrism3=geometry.surfaceAreaOfRectangularPrism(0,0,1);
console.log("Answer "+SurfAreaOfRectPrism3);
}
catch(err){
    console.log(err);
}

try{
    let SurfAreaOfRectPrism4=geometry.surfaceAreaOfRectangularPrism(4,5,null);
console.log("Answer "+SurfAreaOfRectPrism4);
}
catch(err){
    console.log(err);
}

try{
    let SurfAreaOfRectPrism5=geometry.surfaceAreaOfRectangularPrism(1,4,6);
console.log("Answer "+SurfAreaOfRectPrism5);

}
catch(err){
    console.log(err);
}

console.log("");
console.log("Volume of Sphere");
try{
    let VolOfSphere1=geometry.volumeOfSphere(5);
console.log("Answer "+VolOfSphere1);
}
catch(err){
    console.log(err);
}
try{
    let VolOfSphere2=geometry.volumeOfSphere(-1);
console.log("Answer "+VolOfSphere2);
}
catch(err){
    console.log(err);
}
try{
    let VolOfSphere3=geometry.volumeOfSphere(0);
console.log("Answer "+VolOfSphere3);
}
catch(err){
    console.log(err);
}
try{
    let VolOfSphere4=geometry.volumeOfSphere(null);
console.log("Answer "+VolOfSphere4);
}
catch(err){
    console.log(err);
}
try{
    let VolOfSphere5=geometry.volumeOfSphere(undefined);
console.log("Answer "+VolOfSphere5);
}
catch(err){
    console.log(err);
}

console.log("");
console.log("Surface area of Sphere is");
try{
    let SurfAreaOfSphere1=geometry.surfaceAreaOfSphere(6);
console.log("Answer "+SurfAreaOfSphere1);
}
catch(err){
    console.log(err);
}

try{
    let SurfAreaOfSphere2=geometry.surfaceAreaOfSphere(0);
console.log("Answer "+SurfAreaOfSphere2);
}
catch(err){
    console.log(err);
}
try{
    let SurfAreaOfSphere3=geometry.surfaceAreaOfSphere(-2);
console.log("Answer "+SurfAreaOfSphere3);
}
catch(err){
    console.log(err);
}
try{
    let SurfAreaOfSphere4=geometry.surfaceAreaOfSphere(null);
console.log("Answer"+SurfAreaOfSphere4);
}
catch(err){
    console.log(err);
}
try{
    let SurfAreaOfSphere5=geometry.surfaceAreaOfSphere(5);
console.log("Answer "+SurfAreaOfSphere5);
}
catch(err){
    console.log(err);
}

console.log("");
console.log("Utilites section");
console.log("");

console.log("Deep Equality");
 const first = {a: 2, b: 3};
const second = {a: 2, b: 4};
const third = {a: 2, b: 3};
const fourth = {x:3,y:7};
const fifth={here: {is: "an"}, object: 2};
const sixth={"a":{"c":2,"b":1},"z":"test"};
const seventh={"z":"test","a":{"b":1,"c":2}};

try{
   console.log("Answer"+utilities.deepEquality(sixth,seventh)); // false 
}
catch(err){
    console.log(err);
}

try{
   console.log("Answer"+utilities.deepEquality(first, third)); // true  
}
catch(err){
    console.log(err);
}
try{
    console.log("Answer"+utilities.deepEquality(fifth, fifth));//true
}                                                
catch(err){
    console.log(err);
}

try{
    console.log("Answer"+utilities.deepEquality(first, second));//false
}
catch(err){
    console.log(err);
}
try{
    console.log("Answer"+utilities.deepEquality(fourth, third));//false
}
catch(err){
    console.log(err);
}

console.log("");
console.log("Unique elements of array");
try{
console.log("Answer"+utilities.uniqueElements(["a", "a", "b", "a", "b", "c"]));
}
catch(err){
    console.log(err);
}
try{
console.log("Answer"+utilities.uniqueElements(12341234));
}
catch(err){
    console.log(err);
}

try{
    console.log("Answer"+utilities.uniqueElements(["a", "1", "b", "a", "1", "c"]));
}
catch(err){
    console.log(err);
}

try{
    console.log("Answer"+utilities.uniqueElements(["a", "d", "b", "c", "b", "c"]));
}catch(err){
    console.log(err);
}

try{
    console.log("Answer"+utilities.uniqueElements(["a", "a", "b", "a", "b", "c"]));
}
catch(err){
    console.log(err);
}


console.log("");
try{
    console.log("Count of occurence of characters in String");
    console.log(utilities.countOfEachCharacterInString("Hello, the pie is in the oven"));
}catch(err){
    console.log(err);
}

try{
    console.log("Count of occurence of characters in String");
    console.log(utilities.countOfEachCharacterInString("hello world"));
}catch(err){
    console.log(err);
}

try{
    console.log("Count of occurence of characters in String");
    console.log(utilities.countOfEachCharacterInString(12341234));
}catch(err){
    console.log(err);
}

try{
    console.log("Count of occurence of characters in String");
    console.log(utilities.countOfEachCharacterInString("do you wanna have some coffee"))
}catch(err){
    console.log(err);
}
try{
    console.log("Count of occurence of characters in String");
    console.log(utilities.countOfEachCharacterInString("how was your Lecture"));
}catch(err){
    console.log(err);
}

