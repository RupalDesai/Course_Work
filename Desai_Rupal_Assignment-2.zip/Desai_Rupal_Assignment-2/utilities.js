function Helper(obj1,obj2){
    if ((typeof obj1 !== "object" || obj1 === undefined) && (typeof obj2 !== "object" || obj2 === undefined))
    throw "incorrect objects";

    var flag=true;
    var obj1keys=Object.keys(obj1);
    var obj2keys=Object.keys(obj2); 
    
    if(obj1keys.length!=obj2keys.length)
        return false;

    for(let index in obj1){
        if(typeof obj1[index]==="object")  
            flag=Helper(obj1[index],obj2[index]);
        else
            if(obj1[index] !== obj2[index]) return false;
    }
    
    if(flag===false) 
        return false;
    return true;
}
module. exports ={
  deepEquality: function(obj1,obj2){
       return Helper(obj1,obj2);

  },
  uniqueElements: function(arr){
        let unique = [];
        if(!Array.isArray(arr))
        throw "The entered value is not an array"

    for (let i = 0; i < arr.length; i++) {
        let value = arr[i];

      if (!unique.includes(value)) 
      unique.push(value);
    }
    return unique.length;
},
countOfEachCharacterInString: function (str){
    let values=[];
     var t={};
     if(typeof str!="string")
     throw "Invalid input."

    for(let i = 0; i < str.length; i++){
        let value= str.charAt(i);
        // if(value === undefined || typeof value!=="string" || value===null){
        //     throw "Enter proper values";
        // }
        if (!values.includes(value)) {
        values.push(value);
        t[value] = 1;
        }
        else{
            t[value]+=1;
     }
    }

    return t;}

};

