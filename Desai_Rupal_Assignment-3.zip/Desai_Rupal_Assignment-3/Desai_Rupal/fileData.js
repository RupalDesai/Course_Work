const bluebird = require("bluebird");
const Promise = bluebird.Promise;
const fs = bluebird.promisifyAll(require("fs"));

let input="";
module.exports=
{
    async getFileAsString(path)
    { 
        if(path===undefined)
            throw "Undefined Path";
        if(path.length==0)
            throw "Path length is Zero";
        try
        {
            input = await fs.readFileAsync(path, "utf-8");  
        }
        catch(error)
        {
            console.log("Error in getFileAsString");
            throw(error);
        }

    return input;

 },


    async getFileAsJSON(path)
    { 
        if(path===undefined)
            throw "Undefined Path";
        if(path.length==0)
            throw "Path length is zero";
         try
        {
            let str = await module.exports.getFileAsString(path, "utf-8");
            input = JSON.parse(str);
           
        }
        catch(error)
        {
            console.error("Error in getFileAsJSON");
            throw(error);
        }
    return input;
          
    },

    async saveStringToFile(path, value)
    {
        if(typeof value!=='string') 
            throw ("Invalid Text value");
        if(path===undefined)
            throw "Undefined Path";
        if(path.length==0)
            throw "Path length is zero";

        try
        {
            await fs.writeFileAsync(path, value);
        }
        catch(error)
        {
            console.error("Error in saveStringToFile");
            throw(error);
        }
        
        return true;        
    },

    async saveJSONToFile(path, object)
    {
        if(path===undefined)
            throw "Undefined Path";
        if(path.length==0)
            throw "Path length is zero";
        if(object==null) 
            throw "object is null";
        try
        {
            let result=JSON.stringify(object);
            await fs.writeFileAsync(path, result);
        }
        catch(error)
        {
            console.log("Error in saveJSONToFile");
            throw (error);
        }    
        return true;    
    }
}