const tm = require("./textMetrics");
const prompt = require("prompt");
const fd = require("./fileData");
const bluebird = require("bluebird");
const Promise = bluebird.Promise;
const fs = bluebird.promisifyAll(require("fs"));
 
FileOperations();
async function FileOperations(){
    try{
        

              fs.exists('./chapter1.result.json',async function(exists) {
                if(exists){
                    console.log("JSON file already exist");
                    let result1= await fd.getFileAsJSON("./chapter1.result.json");
                    console.log(result1);
                    
                    
                  }
                  else {
                    let result1= await fd.getFileAsString("./chapter1.txt");
                    
                    let result2=await tm.simplify(result1); 
                    await fd.saveStringToFile("./chapter1.debug.txt",result2)
                                    
                    let result3= await tm.createMetrics(result2)                                    
                    await fd.saveJSONToFile("./chapter1.result.json",result3)
                    console.log("File saved as JSON Successfully \n:");

                  }
              }); 
              fs.exists('./chapter2.result.json',async function(exists) {
                if(exists){
                    console.log("JSON file already exist");
                    let result1= await fd.getFileAsJSON("./chapter2.result.json");
                    console.log(result1);
                    
                    
                  }
                  else {
                    let result1= await fd.getFileAsString("./chapter2.txt");
                    
                    let result2=await tm.simplify(result1); 
                    await fd.saveStringToFile("./chapter2.debug.txt",result2)
                                    
                    let result3= await tm.createMetrics(result2)                                    
                    await fd.saveJSONToFile("./chapter2.result.json",result3)
                    console.log("File saved as JSON Successfully \n:");

                  }
              }); 
            
              fs.exists('./chapter3.result.json',async function(exists) {
                if(exists){
                    console.log("JSON file already exist");
                    let result1= await fd.getFileAsJSON("./chapter3.result.json");
                    console.log(result1);
                    
                    
                  }
                  else {
                    let result1= await fd.getFileAsString("./chapter3.txt");
                    
                    let result2=await tm.simplify(result1); 
                    await fd.saveStringToFile("./chapter3.debug.txt",result2)
                                    
                    let result3= await tm.createMetrics(result2)                                    
                    await fd.saveJSONToFile("./chapter3.result.json",result3)
                    console.log("File saved as JSON Successfully \n:");

                  }
              }); 
         }
          catch(e){
               throw (e)
            }

}

