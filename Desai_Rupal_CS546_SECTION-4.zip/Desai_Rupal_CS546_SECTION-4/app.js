const todoItems = require("./todo");
const connection = require("./mongoConnection");

const main = async () => {
    let title1 = "Ponder Dinosaurs", title2 = "Play Pokemon with Twitch TV";
    let description1 = "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?", description2 = "Should we revive Helix?";


    // Create a task with the following details
    const createdTask1 = await todoItems.createTask(title1, description1);
    console.log("\nFirst task");
    console.log(createdTask1);
    // Log the task, and then create a new task with the following details
    const createdTask2 = await todoItems.createTask(title2, description2);
    // After the task is inserted, query all tasks and log them
    const getTasks = await todoItems.getAllTasks();
    console.log("\nAll task");
    console.log(getTasks);
    // After all the tasks are logged, remove the first task
    const removeTask = await todoItems.removeTask(createdTask1._id);
   
    //    Query all the remaining tasks and log them
       const getTasks2 = await todoItems.getAllTasks();
       console.log("\nAfter removing first task");
       console.log(getTasks2);
    // Complete the remaining task
       
       const finishedTask = await todoItems.completeTask(createdTask2._id); 
    //    Log the task that has been completed with its new value.
       console.log('\nfinishedTask');
       const getTasks3 = await todoItems.getAllTasks();
       console.log(getTasks3);
   


    const db = await connection();
    await db.serverConfig.close();
  
    console.log("Done!");
  };
  
  main().catch(error => {
    console.log(error);
  });
  