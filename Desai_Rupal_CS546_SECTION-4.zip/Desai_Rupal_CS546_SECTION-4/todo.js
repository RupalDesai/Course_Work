const mongoCollections = require("./mongoCollections");
const todoItems = mongoCollections.todoItems;

let exportedMethods = {
    
    async getTask(id) {
      if (!id) throw "You must provide an id to search for";
  
      const todoItemsCollection = await todoItems();
      const todos = await todoItemsCollection.findOne({ _id: id });
      if (todos === null) throw "No todo with that id";
  
      return todos;
    },//done
   
    async getAllTasks() {
      const todoCollection = await todoItems();
  
      const todos = await todoCollection.find({}).toArray();
  
      return todos;
    },//done


  
async createTask(title, description) {
    if (!title) throw "You must provide a title for your task";

    if (!description)
      throw "You must provide an description of task";

    const uuidV4 = require('uuid/v4');
    let randomID = uuidV4();
    const todoCollection = await todoItems();

    let newTask = {
        _id: randomID,
        title: title,
        description: description,
        completed: false,
        completedAt: null
    };

    const insertInfo = await todoCollection.insertOne(newTask);
    if (insertInfo.insertedCount === 0) throw "Could not add task";

    const newId = insertInfo.insertedId;

    const task = await this.getTask(newId);
    return task;
  },//done


    async removeTask(id) {
    if(!id) throw "You must provide an id to search for";
        try{
    let tryToGetTask = this.getTask(id);
        }
        catch(error){
            return error;
        }
      const todoCollection = await todoItems();
      const deletionInfo = await todoCollection.removeOne({ _id: id });
  
      if (deletionInfo.deletedCount === 0) {
        throw `Could not delete post with id of ${id}`;
      }
    //   0;
    },//done


async completeTask(taskId){
    if (!taskId) throw "You must provide an id to search for";

       let dt= new Date();
       let time= dt.getTime();
       try{
        const todoCollection=await todoItems();
        const complete= await todoCollection.update(
                                { _id: taskId },
                                { $set: { "completed": "true",
                                           "completedAt":new Date } }
                            )
        return complete;
       }catch(error){
        console.log(error);
       }
            

},//done
  };
  
  module.exports = exportedMethods;